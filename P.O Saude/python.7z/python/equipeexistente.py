import pandas as pd
import json

def process_professionals(professionals_csv, el_json, output_json, cnes_output_json):
    # Load the professionals CSV file with specified dtype
    dtype = {
        'NOME': str, 'CNS': str, 'SEXO': str, 'IBGE': str, 'UF': str, 'MUNICIPIO': str,
        'CBO': str, 'DESCRICAO CBO': str, 'CNES': str, 'CNPJ': str, 'ESTABELECIMENTO': str,
        'NATUREZA JURIDICA': str, 'DESCRICAO NATUREZA JURIDICA': str, 'GESTAO': str, 'SUS': str,
        'RESIDENTE': str, 'PRECEPTOR': str, 'VINCULO ESTABELECIMENTO': str, 'VINCULO EMPREGADOR': str,
        'DETALHAMENTO DO VINCULO': str, 'CH OUTROS': float, 'CH AMB.': float, 'CH HOSP.': float
    }
    df = pd.read_csv(professionals_csv, delimiter=';', dtype=dtype)

    # Load the EL JSON file
    with open(el_json, 'r', encoding='utf-8') as file:
        el_data = json.load(file)

    # Get the list of hospital names from the EL data
    hospital_names = [el['name'] for el in el_data]

    # Filter professionals by SUS and those working in the hospitals
    df_sus = df[(df['SUS'] == 'S') & (df['ESTABELECIMENTO'].isin(hospital_names))]

    # Divide the working hours by 40
    df_sus['CH HOSP.'] = df_sus['CH HOSP.'] / 40

    # Aggregate information
    total_ch_hosp = df_sus['CH HOSP.'].sum()
    descricao_cbo = df_sus.groupby('DESCRICAO CBO')['CH HOSP.'].sum().sort_values(ascending=False).to_dict()

    # Apply Pareto principle to include only the top 80% of working hours
    aggregated_data = {
        'total_ch_hosp': total_ch_hosp,
        'descricao_cbo': {}
    }
    cumulative_hours = 0
    for cbo, hours in descricao_cbo.items():
        if cumulative_hours / total_ch_hosp <= 0.8:
            aggregated_data['descricao_cbo'][cbo] = hours
            cumulative_hours += hours
        else:
            break

    # Save the aggregated data to the output JSON file
    with open(output_json, 'w', encoding='utf-8') as file:
        json.dump(aggregated_data, file, ensure_ascii=False, indent=4)

    # Create CNES data for professionals within the Pareto team
    pareto_cbo = set(aggregated_data['descricao_cbo'].keys())
    df_pareto = df_sus[df_sus['DESCRICAO CBO'].isin(pareto_cbo)]
    descricao_cbo_unit = df_pareto.groupby(['DESCRICAO CBO', 'ESTABELECIMENTO'])['CH HOSP.'].sum().to_dict()

    cnes_data = {}
    for (cbo, estabelecimento), hours in descricao_cbo_unit.items():
        if estabelecimento not in cnes_data:
            cnes_data[estabelecimento] = {}
        cnes_data[estabelecimento][cbo] = hours

    # Save the CNES data to the CNES output JSON file
    with open(cnes_output_json, 'w', encoding='utf-8') as file:
        json.dump(cnes_data, file, ensure_ascii=False, indent=4)

if __name__ == "__main__":
    levels = ['1', '2', '3']
    for level in levels:
        professionals_csv = f'profissionais-310620.csv'  # Replace with your professionals CSV file path
        el_json = f'dados_json/EL_{level}.json'  # Replace with your EL JSON file path
        output_json = f'dados_json/Equipe_{level}.json'  # Replace with your output JSON file path
        cnes_output_json = f'dados_json/CNES_{level}.json'  # Replace with your CNES output JSON file path

        process_professionals(professionals_csv, el_json, output_json, cnes_output_json)
