#ifndef HEURISTICA_H
#define HEURISTICA_H

#include "./data.h"

int find_nearest_neighbor(Matrix);

#endif // HEURISTICA_H